# monteC
multithreading calculation of monte carlo aproach by c++
